rm(list=ls())

## Assume the working directory is where it was run from in robotnik-net

## Load packages
require(np)
require(parallel)

options(np.messages=FALSE)

## Data generation function
data.generate <- function(n,data.type,sigma){
  if (data.type=="pyramidJump"){
    X_1 <- X_2 <- oracle <- NULL
    for (x_1 in seq(-6,6,length.out = n)){
      for (x_2 in seq(-6,6,length.out = n)){
        X_1 <- c(X_1,x_1);X_2 <- c(X_2,x_2)
        if (abs(x_1)<2&abs(x_2)<2){
          oracle <- c(oracle,3)
        } else if (abs(x_1)<4&abs(x_2)<4){
          oracle <- c(oracle,7)
        } else {
          oracle <- c(oracle,1)
        }
      }
    }
  } else if (data.type=="hallJump"){ #not cartesian based function
    cartesianToPolar <- function(x,y) c(sqrt(x^2+y^2),atan2(y,x))
    X_1 <- X_2 <- oracle <- NULL
    for (x_1 in seq(-0.6,0.6,length.out = n)){
      for (x_2 in seq(-0.6,0.6,length.out = n)){
        X_1 <- c(X_1,x_1);X_2 <- c(X_2,x_2)
        polar <- cartesianToPolar(x_1,abs(x_2))
        if (8*polar[1] <= exp(cos(3*polar[2]))+sin(polar[2]/2)){oracle <- c(oracle,4)} else {oracle <- c(oracle,0)}
      }
    }
  }
  Y <- oracle + rnorm(length(oracle),sd=sigma)
  data.frame(X_1=X_1,X_2=X_2,Y=Y,oracle=oracle)
}

## A Monte Carlo step written as a function
simulation.LCAS <- function(seed,n,data.type="pyramidJump",sigma,bw.fixed.value=NULL,
                            repeats=1,ckertype,bwmethod,regtype){
  set.seed(42+seed)## Generate data
  data <- data.generate(n,data.type = data.type,sigma = sigma)
  
  ## Fit data using local constant kernel estimator (LCKE)
  bw.lc <- npregbw(Y~X_1+X_2,data=data,regtype=regtype,bwmethod=bwmethod,ckertype=ckertype)
  model.lc <- npreg(bw.lc)

  ## Set this temporarily...
  model.llc <- model.lc

  ## Use LCKE \widehat{g}(x) as pilot g(x) in LCAS for the first time,
  ## and then LCAS for each repeat
  for (i in 1:repeats){
    data <- data.frame(oracle=data$oracle,X_1=data$X_1,X_2=data$X_2,Y=data$Y,gX=model.llc$mean)
    ## Refit data using the local constant estimator as an input
    bw.llc <- npregbw(Y~X_1+X_2+gX,data=data,regtype=regtype,bwmethod=bwmethod,ckertype=ckertype)
    if (!is.null(bw.fixed.value)){
      bw.llc$bw <- c(bw.llc$bw[1],bw.fixed.value)
    }
    model.llc <- npreg(bw.llc)
  }

  ## Plotting, if you're interested
#  require(plotly)
# data2 <- data.frame(x=data$X_1,y=data$X_2,z=data$oracle) 
#  plot_ly() %>%
#    add_trace(data = data2,  x=data2$x, y=data2$y, z=data2$z, type="mesh3d" )
#  data2 <- data.frame(x=data$X_1,y=data$X_2,z=data$Y) 
#  plot_ly() %>%
#    add_trace(data = data2,  x=data2$x, y=data2$y, z=data2$z, type="mesh3d" )
#  data2 <- data.frame(x=data$X_1,y=data$X_2,z=model.lc$mean) 
#  plot_ly() %>%
#    add_trace(data = data2,  x=data2$x, y=data2$y, z=data2$z, type="mesh3d" )
#  data2 <- data.frame(x=data$X_1,y=data$X_2,z=model.llc$mean) 
#  plot_ly() %>%
#    add_trace(data = data2,  x=data2$x, y=data2$y, z=data2$z, type="mesh3d" )
  ## Check fit with oracle function and retern mean squared error
  model.lc.ESE <- mean((model.lc$mean-data$oracle)^2)
  model.llc.ESE <- mean((model.llc$mean-data$oracle)^2)
  
  c(model.lc.ESE,model.llc.ESE)
}  

## Code to run all simulations desired, need different number of points, 
## variability of data, and kernel type, and split by number of cores

cores <- detectCores()-1

kernel.type <- "epanechnikov" #could try others in the future
bandwidth.selection.method <- "cv.ls" #could try others in the future
regression.type <- "lc" #lc for local constant, ll for local linear
data.types <- c("pyramidJump","hallJump")
repeats <- 1 #how many times to repeat the LCAS smoother
bw.fixed.value <- NULL #set this for specifying the LCAS bw value

M <- 63 #number of Monte Carlo replicates, 63*2-1 =125 cores
n.seq <- c(10,20,40,80,160)
sigma.seq <- c(0.1,0.5,1,2)

lcr.MSE <- numeric(length(n.seq))
lcas.MSE <- numeric(length(n.seq))
lcr.ESE <- matrix(numeric(M),M,length(n.seq))
lcas.ESE <- matrix(numeric(M),M,length(n.seq))

date.started <- as.character(Sys.Date())
time.started <- proc.time()

for (data.type in data.types){
  for (sigma in sigma.seq){
    for (N in 1:length(n.seq)){
      dum = mclapply(1:M,function(m) simulation.LCAS(m,n.seq[N],data.type,
                                                     sigma,bw.fixed.value,
                                                     repeats, kernel.type,
                                                     bandwidth.selection.method,
                                                     regression.type),
                     mc.cores=cores)
      lcr.ESE[,N] <- simplify2array(dum)[1,]
      lcas.ESE[,N] <- simplify2array(dum)[2,]
    }
    
    return.SEs <- data.frame(lcr=lcr.ESE,lcas=lcas.ESE)
    colnames(return.SEs) <- c(paste("lcr",n.seq,sep="."),paste("lcas",n.seq,sep="."))
    ## Write the current data into a file so we can use it in the future
    write.csv(return.SEs,paste("results/LCASsimulation2D",date.started,data.type,
              sigma,repeats,"csv",sep = "_"),row.names = FALSE)
  }
}

proc.time()-time.started
